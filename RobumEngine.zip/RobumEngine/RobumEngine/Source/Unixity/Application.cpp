#include "Application.h"

namespace Unixity {
	Application::Application()
	{
	}

	Application::~Application()
	{
	}

	void Application::Run()
	{
		while (true);
	}

}