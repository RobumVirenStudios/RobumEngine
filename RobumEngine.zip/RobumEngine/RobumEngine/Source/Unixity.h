#pragma once

// For use by Unixity applications

#include "Unixity/Application.h"

//ENTRY POINT-------------------
#include "Unixity/EntryPoint.h"
//------------------------------
